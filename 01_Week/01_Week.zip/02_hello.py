# Part 2
# Hello 2

# User input
name = input("Enter your name: ")

# print hello with users input if Alice or Bob
if name == 'Alice' or name == 'Bob':
    print('Hello '+ name)

# Else print hello 
else:
    print("Hello")
