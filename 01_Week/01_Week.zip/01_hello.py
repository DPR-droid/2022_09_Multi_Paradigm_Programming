# Part 1
# Hello

# User input
name = input("Enter your name: ")
# print hello with users input
print('Hello '+ name)